import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

// Top Cards Component using shadcn
const TopCards = ({ data, isDark }) => {
  const topThree = data.slice(0, 3);
  
  const getRankStyles = (rank) => {
    switch(rank) {
      case 1:
        return {
          style: {
            background: 'var(--rank1-bg)',
            border: 'none',
            borderImageSource: 'var(--rank1-border)',
            borderImageSlice: 1,
            borderRadius: '40px',
          },
          rankBg: 'var(--rank1-rank-bg)',
          rankColor: 'var(--rank1-rank-color)',
          medalSrc: './medal-1st.png' // Added medal source
        };
      case 2:
        return {
          style: {
            background: 'var(--rank2-bg)',
            border: 'none',
            borderImageSource: 'var(--rank2-border)',
            borderImageSlice: 1,
            borderRadius: '40px',
          },
          rankBg: 'var(--rank2-rank-bg)',
          rankColor: 'var(--rank2-rank-color)',
          medalSrc: './medal-2nd.png'  
        };
      case 3:
        return {
          style: {
            background: 'var(--rank3-bg)',
            border: 'none',
            borderImageSource: 'var(--rank3-border)',
            borderImageSlice: 1,
            borderRadius: '40px',
          },
          rankBg: 'var(--rank3-rank-bg)',
          rankColor: 'var(--rank3-rank-color)',
          medalSrc: './1st.png'  
        };
      default:
        return {
          style: {
            backgroundColor: 'var(--q3-surface-dim)',
            border: '2px solid',
            borderImageSource: 'linear-gradient(180deg, var(--q3-stroke-light) 0%, var(--q3-surface-default) 100%)',
            borderImageSlice: 1,
            borderRadius: '40px',
          },
          rankBg: 'var(--q3-surface-dimmer)',
          rankColor: 'var(--q3-neutral-light)',
          medalSrc: null // No medal for other ranks
        };
    }
  };

  return (
    <div className="hidden lg:grid grid-cols-4 gap-4 mb-6 rounded-4xl">
      {/* Always show first 3 ranks with API data */}
      {topThree.map((student, index) => {
        const styles = getRankStyles(student.rank);
        const physicsScore = student.subjects?.find(s => s.subjectId?.title === 'Physics')?.totalMarkScored || 0;
        const chemScore = student.subjects?.find(s => s.subjectId?.title === 'Chemistry')?.totalMarkScored || 0;
        const mathScore = student.subjects?.find(s => s.subjectId?.title === 'Mathematics')?.totalMarkScored || 0;
        
        return (
          <div 
            key={student.userId._id} 
            className="p-4 space-y-3 overflow-hidden border"
            style={{
              ...styles.style,
              borderColor: 'var(--q3-stroke-normal)'
            }}
          >
            <div className="flex flex-col items-center relative"> {/* Added relative for medal positioning */}
              <Avatar className="w-12 h-12 mb-2">
                <AvatarImage src={student.userId.profilePicture} alt={student.userId.name} />
                <AvatarFallback>{student.userId.name.charAt(0)}</AvatarFallback>
              </Avatar>
              
              {/* Medal Image - positioned absolutely below avatar */}
              {styles.medalSrc && (
                <div 
                  className="absolute" 
                  style={{ 
                    top: '65%', // Adjust this to control vertical position
                    left: '50%', 
                    transform: 'translate(-50%, -50%)', // Center it horizontally
                    zIndex: 10, // Ensure it's above other elements if needed
                    width: '32px', // Size of the medal
                    height: '32px', // Size of the medal
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    borderRadius: '50%', // Make it round if the image itself isn't
                    backgroundColor: 'var(--q3-surface-default)' // Background if medal image is transparent
                  }}
                >
                  <img src={styles.medalSrc} alt={`${student.rank} Rank Medal`} className="w-full h-full object-contain" />
                </div>
              )}

              <h3 className="font-medium text-center mt-3" style={{ color: 'var(--q3-neutral-default)' }}> {/* Adjusted margin-top for name */}
                {student.userId.name}
              </h3>
              <div 
                className="px-2 py-1 rounded text-xs font-medium mt-1"
                style={{ 
                  backgroundColor: styles.rankBg,
                  color: styles.rankColor
                }}
              >
                {student.rank === 1 ? '1st' : student.rank === 2 ? '2nd' : '3rd'} Rank
              </div>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1">
                  <img src='./check.png' alt="Overall Score icon"/>
                  <span style={{ color: 'var(--q3-neutral-light)' }}>Overall Score</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>
                  {student.totalMarkScored}
                  <span className="text-xs ml-1" style={{ color: 'var(--q3-neutral-light)' }}>/300</span>
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1">
                 <img src='./atom.png' alt="Physics Score icon"/>
                  <span style={{ color: 'var(--q3-neutral-light)' }}>Phy Score</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>
                  {physicsScore}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1">
                 <img src='./glass.png' alt="Chemistry Score icon"/>
                  <span style={{ color: 'var(--q3-neutral-light)' }}>Chem Score</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>
                  {chemScore}
                </span>
              </div>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1">
                 <img src='./multiplication.png' alt="Maths Score icon"/>
                  <span style={{ color: 'var(--q3-neutral-light)' }}>Maths Score</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>
                  {mathScore}
                </span>
              </div>

              {/* Accuracy Column Added Back */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-1">
                  <img src='./accry.png' alt="Accuracy icon"/>
                  <span style={{ color: 'var(--q3-neutral-light)' }}>Accuracy</span>
                </div>
                <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>
                  {student.accuracy.toFixed(2)}%
                </span>
              </div>
            </div>
          </div>
        );
      })}
      
      {/* Current User Card - Desktop Only */}
      <div 
        className="p-4 space-y-3 overflow-hidden rounded-[40px] border"
        style={{
          backgroundColor: 'var(--q3-surface-dim)',
          borderColor: 'var(--q3-stroke-normal)'
        }}
      >
        <div className="flex flex-col items-center">
          <Avatar className="w-12 h-12 mb-2">
            <AvatarImage 
              src="https://ui-avatars.com/api/?name=Prem%20Raj%20Kumar&background=6366f1&color=fff " 
              alt="Prem Raj Kumar" 
            />
            <AvatarFallback>PR</AvatarFallback>
          </Avatar>
          <h3 className="font-medium text-center" style={{ color: 'var(--q3-neutral-default)' }}>
            Prem Raj Kumar (You)
          </h3>
          <div 
            className="px-2 py-1 rounded text-xs font-medium mt-1 border "
            style={{ 
              backgroundColor: 'transparent',
              color: 'var(--q3-neutral-light)',
              borderColor: 'var(--q3-stroke-normal)'
            }}
          >
            73th Rank
          </div>
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <span style={{ color: 'var(--q3-success-normal)' }}>✓</span>
              <span style={{ color: 'var(--q3-neutral-light)' }}>Overall Score</span>
            </div>
            <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>
              109
              <span className="text-xs ml-1" style={{ color: 'var(--q3-neutral-light)' }}>/300</span>
            </span>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <span style={{ color: 'var(--q3-blue-normal)' }}>⚪</span>
              <span style={{ color: 'var(--q3-neutral-light)' }}>Phy Score</span>
            </div>
            <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>66</span>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <span style={{ color: 'var(--q3-danger-normal)' }}>🔴</span>
              <span style={{ color: 'var(--q3-neutral-light)' }}>Chem Score</span>
            </div>
            <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>66</span>
          </div>
          
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <span style={{ color: 'var(--q3-orange-normal)' }}>➖</span>
              <span style={{ color: 'var(--q3-neutral-light)' }}>Maths Score</span>
            </div>
            <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>67</span>
          </div>

          {/* Accuracy Column Added Back */}
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-1">
              <span style={{ color: 'var(--q3-purple-normal)' }}>⚪</span>
              <span style={{ color: 'var(--q3-neutral-light)' }}>Accuracy</span>
            </div>
            <span className="font-semibold" style={{ color: 'var(--q3-neutral-default)' }}>80.30%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Leaderboard Table Component
const LeaderboardTable = ({ data, currentPage, setCurrentPage, totalPages, loading }) => {
  const headerRef = useRef(null);
  const bodyRef = useRef(null);
  const [screenSize, setScreenSize] = useState('desktop');

  useEffect(() => {
    const checkScreenSize = () => {
      if (window.innerWidth < 640) {
        setScreenSize('mobile');
      } else if (window.innerWidth < 1024) {
        setScreenSize('tablet');
      } else {
        setScreenSize('desktop');
      }
    };

    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // Synchronize horizontal scroll between header and body
  const handleBodyScroll = (e) => {
    if (headerRef.current) {
      headerRef.current.scrollLeft = e.target.scrollLeft;
    }
  };

  const handleHeaderScroll = (e) => {
    if (bodyRef.current) {
      bodyRef.current.scrollLeft = e.target.scrollLeft;
    }
  };

  const tableData = data;

  const goToPage = (page) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
    }
  };

  // Get grid template columns based on screen size
  const getGridColumns = () => {
    switch (screenSize) {
      case 'mobile':
        return 'minmax(120px, 1fr) 70px 60px 60px 60px 70px';
      case 'tablet':
        return '50px minmax(140px, 1fr) 100px 70px 70px 70px 80px';
      default:
        return '80px minmax(200px, 1fr) 150px 100px 100px 100px 100px';
    }
  };

  // Get minimum width based on screen size
  const getMinWidth = () => {
    switch (screenSize) {
      case 'mobile':
        return '520px';
      case 'tablet':
        return '580px';
      default:
        return '830px';
    }
  };

  // Get font size based on screen size
  const getFontSize = () => {
    switch (screenSize) {
      case 'mobile':
        return 'text-xs';
      case 'tablet':
        return 'text-xs';
      default:
        return 'text-sm';
    }
  };

  if (loading) {
    return (
      <Card className="overflow-hidden">
        <div className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-2 text-muted-foreground">Loading leaderboard...</p>
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col overflow-hidden rounded-lg border" style={{ 
        borderColor: 'var(--q3-stroke-normal)', 
        backgroundColor: 'var(--q3-surface-default)',
        height: '70vh',
        minHeight: '600px'
      }}>
        <div 
          ref={headerRef}
          className="overflow-x-auto scrollbar-none flex-shrink-0"
          onScroll={handleHeaderScroll}
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          <div 
            className={`border-b px-4 py-2 font-medium grid gap-1 items-center ${getFontSize()}`}
            style={{ 
              gridTemplateColumns: getGridColumns(),
              borderBottomColor: 'var(--q3-stroke-normal)',
              backgroundColor: 'var(--q3-surface-dim)',
              color: 'var(--q3-neutral-light)',
              minWidth: getMinWidth()
            }}
          >
            {screenSize === 'mobile' ? (
              <>
                <div className="text-left">Student</div>
                <div className="text-right">Overall</div>
                <div className="text-right">Phy</div>
                <div className="text-right">Chem</div>
                <div className="text-right">Math</div>
                <div className="text-right">Acc</div>
              </>
            ) : (
              <>
                <div className="text-center">Rank</div>
                <div className="text-left">Student Name</div>
                <div className="text-right">Overall</div>
                <div className="text-right">Phy</div>
                <div className="text-right">Chem</div>
                <div className="text-right">Math</div>
                <div className="text-right">Accuracy</div>
              </>
            )}
          </div>
        </div>
        
        <div 
          ref={bodyRef}
          className="flex-1 overflow-auto"
          onScroll={handleBodyScroll}
        >
          <div style={{ minWidth: getMinWidth() }}>
            {tableData.map((student) => {
              const physicsScore = student.subjects?.find(s => s.subjectId?.title === 'Physics')?.totalMarkScored || 0;
              const chemScore = student.subjects?.find(s => s.subjectId?.title === 'Chemistry')?.totalMarkScored || 0;
              const mathScore = student.subjects?.find(s => s.subjectId?.title === 'Mathematics')?.totalMarkScored || 0;
              
              const isCurrentUser = student.userId?.name?.includes('(You)') || student.isCurrentUser;
              
              const rankCircleStyles = {
                  1: { backgroundColor: '#FFD700', color: '#000000', boxShadow: '0 0 6px rgba(255, 215, 0, 0.7)' },
                  2: { backgroundColor: '#C0C0C0', color: '#000000', boxShadow: '0 0 6px rgba(192, 192, 192, 0.7)' },
                  3: { backgroundColor: '#CD7F32', color: '#FFFFFF', boxShadow: '0 0 6px rgba(205, 127, 50, 0.7)' },
              };
              const circleStyle = rankCircleStyles[student.rank]
                ? rankCircleStyles[student.rank]
                : { backgroundColor: 'var(--q3-surface-dimmer)', color: 'var(--q3-neutral-light)' };

              return (
                <div 
                  key={student.userId?._id || student.id} 
                  className={`border-b px-4 py-2 grid gap-1 items-center transition-colors hover:opacity-80 ${getFontSize()}`}
                  style={{ 
                    gridTemplateColumns: getGridColumns(),
                    borderBottomColor: 'var(--q3-stroke-light)',
                    color: 'var(--q3-neutral-default)',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.backgroundColor = 'var(--q3-surface-dim)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }}
                >
                  {screenSize === 'mobile' ? (
                    <>
                      <div className="flex items-center gap-2 overflow-hidden">
                        <div className="flex items-center justify-center w-4 h-4 rounded-full text-xs font-bold flex-shrink-0" 
                             style={{ 
                               fontSize: '10px',
                               ...circleStyle
                             }}>
                          {student.rank}
                        </div>
                        <Avatar className="w-4 h-4 flex-shrink-0">
                          <AvatarImage 
                            src={student.userId?.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(student.userId?.name || 'User')}&background=6366f1&color=fff`} 
                            alt={student.userId?.name || 'User'} 
                          />
                          <AvatarFallback className="text-xs" style={{ fontSize: '8px' }}>{(student.userId?.name || 'U').charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="font-medium truncate text-xs">
                          {(student.userId?.name || 'Unknown User').split(' ')[0]}
                        </span>
                      </div>
                      
                      <div className="font-medium text-right text-xs">
                        {student.totalMarkScored || 0}
                      </div>
                      
                      <div className="font-medium text-right text-xs">
                        {physicsScore}
                      </div>
                      
                      <div className="font-medium text-right text-xs">
                        {chemScore}
                      </div>
                      
                      <div className="font-medium text-right text-xs">
                        {mathScore}
                      </div>
                      <div className="font-medium text-right text-xs">{(student.accuracy || 0).toFixed(2)}%</div>
                    </>
                  ) : (
                    <>
                      <div className="font-medium text-center">
                        {student.rank}
                      </div>
                      
                      <div className="flex items-center gap-2 overflow-hidden">
                        <Avatar className={`${screenSize === 'tablet' ? 'w-5 h-5' : 'w-8 h-8'} flex-shrink-0`}>
                          <AvatarImage 
                            src={student.userId?.profilePicture || `https://ui-avatars.com/api/?name=${encodeURIComponent(student.userId?.name || 'User')}&background=6366f1&color=fff`} 
                            alt={student.userId?.name || 'User'} 
                          />
                          <AvatarFallback className={screenSize === 'tablet' ? 'text-xs' : ''}>{(student.userId?.name || 'U').charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span className="font-medium truncate">
                          {screenSize === 'tablet' ? (student.userId?.name || 'Unknown User').split(' ')[0] : (student.userId?.name || 'Unknown User')}
                        </span>
                      </div>
                      
                      <div className="font-medium text-right">
                        {student.totalMarkScored || 0}
                      </div>
                      
                      <div className="font-medium text-right">
                        {physicsScore}
                      </div>
                      
                      <div className="font-medium text-right">
                        {chemScore}
                      </div>
                      
                      <div className="font-medium text-right">
                        {mathScore}
                      </div>
                      <div className="font-medium text-right">{(student.accuracy || 0).toFixed(2)}%</div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 px-4 py-4 border-t flex-shrink-0" style={{
          backgroundColor: 'var(--q3-surface-dim)',
          borderTopColor: 'var(--q3-stroke-normal)'
        }}>
       <button
            className="text-sm hover:opacity-80 disabled:opacity-50 transition-opacity px-3 py-1"
            style={{ color: 'var(--q3-neutral-light)' }}
            onClick={() => goToPage(currentPage - 1)}
            disabled={currentPage === 1}
          >
            Previous
          </button>
          
          {/* Dynamic page numbers */}
          {Array.from({ length: Math.min(3, totalPages) }, (_, i) => {
            const pageNum = i + 1;
            return (
              <button
                key={pageNum}
                className="w-8 h-8 text-sm font-medium rounded-full flex items-center justify-center transition-all"
                style={{
                  backgroundColor: currentPage === pageNum ? 'var(--q3-accent-normal)' : 'transparent',
                  color: currentPage === pageNum ? 'white' : 'var(--q3-neutral-light)'
                }}
                onClick={() => goToPage(pageNum)}
                onMouseEnter={(e) => {
                  if (currentPage !== pageNum) {
                    e.currentTarget.style.backgroundColor = 'var(--q3-surface-default)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (currentPage !== pageNum) {
                    e.currentTarget.style.backgroundColor = 'transparent';
                  }
                }}
              >
                {pageNum}
              </button>
            );
          })}
          
          {totalPages > 3 && (
            <>
              <span className="text-sm px-1" style={{ color: 'var(--q3-neutral-light)' }}>...</span>
              
              <button
                className="w-8 h-8 text-sm font-medium rounded-full flex items-center justify-center transition-all"
                style={{
                  backgroundColor: currentPage === totalPages ? 'var(--q3-accent-normal)' : 'transparent',
                  color: currentPage === totalPages ? 'white' : 'var(--q3-neutral-light)'
                }}
                onClick={() => goToPage(totalPages)}
                onMouseEnter={(e) => {
                  if (currentPage !== totalPages) {
                    e.currentTarget.style.backgroundColor = 'var(--q3-surface-default)';
                  }
                }}
                onMouseLeave={(e) => {
                  if (currentPage !== totalPages) {
                    e.currentTarget.style.backgroundColor = 'var(--q3-surface-default)';
                  }
                }}
              >
                {totalPages}
              </button>
            </>
          )}
          
          <button
            className="text-sm hover:opacity-80 disabled:opacity-50 transition-opacity px-3 py-1"
            style={{ color: 'var(--q3-neutral-light)' }}
            onClick={() => goToPage(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
};

// Main Leaderboard App
const LeaderboardApp = () => {
  const [isDark, setIsDark] = useState(false);
  const [data, setData] = useState([]);
  const [topPerformers, setTopPerformers] = useState([]); // State for top 3
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch paginated leaderboard data
  const fetchLeaderboardData = async (page = 1) => {
    try {
      setLoading(true);
      setError(null);
      const response = await fetch(`https://api.quizrr.in/api/hiring/leaderboard?page=${page}&limit=100`);
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const result = await response.json();
      if (result.success && result.data) {
        setData(result.data.results || []);
        const totalItems = result.data.totalCount || 0;
        setTotalPages(Math.ceil(totalItems / 100));
      } else {
        throw new Error('Invalid API response structure');
      }
    } catch (err) {
      console.error('Error fetching leaderboard data:', err);
      setError(err.message);
      setData([]);
      setTotalPages(1);
    } finally {
      setLoading(false);
    }
  };

  // Fetch top 3 performers on initial mount
  useEffect(() => {
    const fetchTopThree = async () => {
        try {
            const response = await fetch(`https://api.quizrr.in/api/hiring/leaderboard?page=1&limit=3`);
            if (!response.ok) throw new Error('Failed to fetch top performers');
            const result = await response.json();
            if (result.success && result.data) {
                setTopPerformers(result.data.results || []);
            }
        } catch (err) {
            console.error("Error fetching top performers:", err);
        }
    };
    fetchTopThree();
    fetchLeaderboardData(1); // Fetch the first page for the main table
  }, []); // Empty dependency array means this runs once on mount

  // Fetch data when currentPage changes
  useEffect(() => {
    // Only fetch if currentPage actually changes from its initial value or after an explicit page change
    // This prevents double-fetching on initial mount with fetchLeaderboardData(1) above
    if (currentPage > 1 || (currentPage === 1 && data.length === 0 && !loading && !error)) { 
        fetchLeaderboardData(currentPage);
    }
  }, [currentPage]); // Dependency on currentPage

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  const toggleTheme = () => setIsDark(!isDark);
  const handlePageChange = (page) => setCurrentPage(page);

  return (
    <div className="min-h-screen transition-colors" style={{ backgroundColor: 'var(--q3-surface-default)', color: 'var(--q3-neutral-default)' }}>
      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2 sm:gap-4">
            <Button variant="ghost" size="sm" className="p-2" style={{ color: 'var(--q3-neutral-default)' }}>
              <ChevronLeft size={20} />
            </Button>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold" style={{ color: 'var(--q3-neutral-default)' }}>
                Leaderboard
              </h1>
              <p className="text-xs sm:text-sm hidden sm:block" style={{ color: 'var(--q3-neutral-light)' }}>
                JEE Main Test series / Qatar Part Test / Qatar Part Test DPP 11 - 1 CMU / Analysis / Leaderboard
              </p>
            </div>
          </div>
          <Button 
            onClick={toggleTheme} 
            variant="outline" 
            size="sm"
            className='cursor-pointer'
            style={{ 
              borderColor: 'var(--q3-stroke-normal)', 
              color: 'var(--q3-neutral-default)',
              backgroundColor: 'transparent'
            }}
          >
            {isDark ? '🌞' : '🌙'}
            <span className="hidden sm:inline ml-2">
              {isDark ? 'Light' : 'Dark'}
            </span>
          </Button>
        </div>

        {/* Pass topPerformers data to TopCards */}
        {topPerformers.length > 0 && <TopCards data={topPerformers} isDark={isDark} />}

        {error && !loading && (
          <div className="mb-4 overflow-hidden rounded-lg border" style={{ 
            borderColor: 'var(--q3-danger-normal)', 
            backgroundColor: 'var(--q3-danger-light)' 
          }}>
            <div className="p-4">
              <div className="text-center" style={{ color: 'var(--q3-danger-dark)' }}>
                <p>Error loading data: {error}</p>
                <Button 
                  onClick={() => fetchLeaderboardData(currentPage)} 
                  variant="outline" 
                  size="sm" 
                  className="mt-2"
                  style={{ 
                    borderColor: 'var(--q3-danger-normal)', 
                    color: 'var(--q3-danger-dark)'
                  }}
                >
                  Retry
                </Button>
              </div>
            </div>
          </div>
        )}

        <LeaderboardTable 
          data={data} 
          currentPage={currentPage}
          setCurrentPage={handlePageChange}
          totalPages={totalPages}
          loading={loading}
        />
      </div>
    </div>
  );
};

export default LeaderboardApp;